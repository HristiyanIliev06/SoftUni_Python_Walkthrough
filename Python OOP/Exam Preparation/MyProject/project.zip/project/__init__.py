'''from climbers.base_climber import BaseClimber
from peaks.base_peak import BasePeak
from peaks.arctic_peak import ArcticPeak

bc = BaseClimber("sffdeg", 100)
print(str(bc))
ap = ArcticPeak("sffdeg", 3000)
print(ap.calculate_difficulty_level())'''